const cron = require("node-cron");
const db = require("../config/db");

cron.schedule("*/10 * * * *", async () => {
  await db.query(
    `DELETE FROM stories WHERE expires_at < NOW()`
  );

  console.log("Süresi dolan story'ler silindi");
});
