const cron = require("node-cron");
const db = require("../db");

function startStoryCleanupJob() {
  console.log("🧹 Story cleanup job başladı (her dakika kontrol, 24 saat dolunca siler)");

  // Her dakika çalışır: silme sadece expires_at <= NOW olanlara uygulanır
  cron.schedule("* * * * *", async () => {
    try {
      const [result] = await db.execute(
        "DELETE FROM stories WHERE expires_at <= NOW()"
      );

      if (result.affectedRows > 0) {
        console.log(`🗑️ [CLEANUP] Deleted ${result.affectedRows} expired stories`);
      } else {
        console.log("✅ [CLEANUP] Silinecek story yok");
      }
    } catch (err) {
      console.error("❌ [CLEANUP] Error:", err.message);
    }
  });
}

module.exports = { startStoryCleanupJob };
