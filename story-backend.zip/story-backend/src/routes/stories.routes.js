const express = require("express");
const router = express.Router();
const db = require("../db");

// ✅ Router çalışıyor mu testi
router.get("/test", (req, res) => {
  res.json({ ok: true, route: "stories", time: new Date().toISOString() });
});

/**
 * 1) Story paylaş
 * POST /stories
 * Body: { "userId": 1, "imageUrl": "..." } veya { "userId": 1, "videoUrl": "..." }
 */
router.post("/", async (req, res) => {
  const userId = Number(req.body?.userId);
  const imageUrl = req.body?.imageUrl || null;
  const videoUrl = req.body?.videoUrl || null;

  if (!userId) return res.status(400).json({ error: "userId zorunlu" });
  if (!imageUrl && !videoUrl)
    return res.status(400).json({ error: "imageUrl veya videoUrl zorunlu" });

  try {
    // ✅ 24 saat sonra expire: Node tarafında hesapla (timezone karmaşası olmaz)
    const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000);

    const [result] = await db.execute(
      `INSERT INTO stories (user_id, image_url, video_url, expires_at)
       VALUES (?, ?, ?, ?)`,
      [userId, imageUrl, videoUrl, expiresAt]
    );

    const storyId = result.insertId;
    const [rows] = await db.execute(
      `SELECT id, user_id, image_url, video_url, created_at, expires_at
       FROM stories
       WHERE id = ?`,
      [storyId]
    );

    res.status(201).json(rows[0]);
  } catch (err) {
    console.error("❌ Story insert error:", err.message);
    res.status(500).json({ error: err.message });
  }
});

/**
 * Ek: Son 20 story (debug)
 * GET /stories
 */
router.get("/", async (req, res) => {
  try {
    const [rows] = await db.execute(
      `SELECT id, user_id, image_url, video_url, expires_at, created_at
       FROM stories
       ORDER BY id DESC
       LIMIT 20`
    );
    res.json(rows);
  } catch (err) {
    console.error("❌ Story list error:", err.message);
    res.status(500).json({ error: err.message });
  }
});

/**
 * Debug: DB NOW / story expires farkı
 * GET /stories/:storyId/debug-time
 */
router.get("/:storyId/debug-time", async (req, res) => {
  const storyId = Number(req.params.storyId);

  try {
    const [rows] = await db.execute(
      `
      SELECT
        id,
        created_at,
        expires_at,
        NOW() AS db_now,
        TIMESTAMPDIFF(MINUTE, NOW(), expires_at) AS minutes_left
      FROM stories
      WHERE id = ?
      `,
      [storyId]
    );

    if (rows.length === 0)
      return res.status(404).json({ error: "Story bulunamadı" });

    res.json(rows[0]);
  } catch (err) {
    console.error("❌ Debug time error:", err.message);
    res.status(500).json({ error: err.message });
  }
});

/**
 * 2) Kullanıcının aktif story’leri
 * GET /stories/active/:userId
 */
router.get("/active/:userId", async (req, res) => {
  const userId = Number(req.params.userId);

  try {
    const [stories] = await db.execute(
      `SELECT *
       FROM stories
       WHERE user_id = ? AND expires_at > NOW()
       ORDER BY created_at DESC`,
      [userId]
    );

    res.json(stories);
  } catch (err) {
    console.error("❌ Active stories error:", err.message);
    res.status(500).json({ error: err.message });
  }
});

/**
 * 3) Feed: viewerId'nin takip ettikleri + kendi storyleri
 * GET /stories/feed/:viewerId
 */
router.get("/feed/:viewerId", async (req, res) => {
  const viewerId = Number(req.params.viewerId);

  try {
    const [stories] = await db.execute(
      `
      SELECT s.*, u.username, u.profile_picture_url
      FROM stories s
      JOIN users u ON u.id = s.user_id
      WHERE s.expires_at > NOW()
        AND (
          s.user_id = ?
          OR s.user_id IN (
            SELECT following_id FROM follows WHERE follower_id = ?
          )
        )
      ORDER BY s.created_at DESC
      `,
      [viewerId, viewerId]
    );

    res.json(stories);
  } catch (err) {
    console.error("❌ Feed stories error:", err.message);
    res.status(500).json({ error: err.message });
  }
});

/**
 * 4) Story görüntüle (view kaydı ekle)
 * POST /stories/:storyId/view
 * Body: { "userId": 5 }
 */
router.post("/:storyId/view", async (req, res) => {
  const storyId = Number(req.params.storyId);
  const userId = Number(req.body?.userId);

  if (!userId) return res.status(400).json({ error: "userId zorunlu" });

  try {
    const [storyRows] = await db.execute(
      "SELECT id, expires_at FROM stories WHERE id = ?",
      [storyId]
    );

    if (storyRows.length === 0)
      return res.status(404).json({ error: "Story bulunamadı" });

    const [activeCheck] = await db.execute(
      "SELECT id FROM stories WHERE id = ? AND expires_at > NOW()",
      [storyId]
    );

    if (activeCheck.length === 0)
      return res.status(410).json({ error: "Story süresi dolmuş" });

    await db.execute(
      "INSERT IGNORE INTO story_views (story_id, user_id) VALUES (?, ?)",
      [storyId, userId]
    );

    res.json({ ok: true, message: "View kaydedildi" });
  } catch (err) {
    console.error("❌ Story view error:", err.message);
    res.status(500).json({ error: err.message });
  }
});

/**
 * 5) Story görenler listesi
 * GET /stories/:storyId/views
 */
router.get("/:storyId/views", async (req, res) => {
  const storyId = Number(req.params.storyId);

  try {
    const [views] = await db.execute(
      `
      SELECT sv.user_id, u.username, u.profile_picture_url, sv.viewed_at
      FROM story_views sv
      JOIN users u ON u.id = sv.user_id
      WHERE sv.story_id = ?
      ORDER BY sv.viewed_at DESC
      `,
      [storyId]
    );

    res.json(views);
  } catch (err) {
    console.error("❌ Story views list error:", err.message);
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
