const express = require("express");
const storyRoutes = require("./routes/story.routes");

const app = express();

app.use(express.json());

// test endpoint (çok önemli)
app.get("/", (req, res) => {
  res.send("API çalışıyor 🚀");
});

app.use("/stories", storyRoutes);

module.exports = app; // 🔴 BU SATIR ŞART
