// src/server.js
const express = require("express");
const mysql = require("mysql2/promise");
require("dotenv").config();

const app = express();
app.use(express.json());
app.set("json spaces", 2);

console.log("🔥 SERVER.JS AKTIF");

// ✅ PORT
const PORT = Number(process.env.PORT || 3000);

// ✅ DB ayarları (şifre kodda)
const DB_HOST = "localhost";
const DB_USER = "root";
const DB_PASS = "748365";
const DB_NAME = "maunsosyal2";
const DB_PORT = 3306;

// --------------------
// ROUTE LOG MIDDLEWARE
// --------------------
app.use((req, res, next) => {
  const start = Date.now();

  res.on("finish", () => {
    const ms = Date.now() - start;
    console.log(`➡️  ${req.method} ${req.originalUrl} -> ${res.statusCode} (${ms}ms)`);
  });

  next();
});

// --------------------
// ROUTES
// --------------------
console.log("🧩 ROUTES yükleniyor...");

const storiesRouter = require("./routes/stories.routes");
app.use("/stories", storiesRouter);

console.log("✅ ROUTES yüklendi: /stories");

// ---- HEALTH
app.get("/", (req, res) => {
  res.json({ ok: true, service: "story-backend" });
});

// ---- DB PING
app.get("/db/ping", async (req, res) => {
  let conn;
  try {
    conn = await mysql.createConnection({
      host: DB_HOST,
      user: DB_USER,
      password: DB_PASS,
      database: DB_NAME,
      port: DB_PORT,
    });

    await conn.query("SELECT 1");
    res.json({ ok: true, db: "connected" });
  } catch (err) {
    console.error("❌ DB Ping Error:", err.message);
    res.status(500).json({ ok: false, error: err.message });
  } finally {
    if (conn) await conn.end();
  }
});

// ---- TEST INSERT USER
app.post("/test-user", async (req, res) => {
  let conn;
  try {
    const username = req.body?.username || "testuser3";
    const email = req.body?.email || "test3@mail.com";
    const password_hash = req.body?.password_hash || "123456";

    conn = await mysql.createConnection({
      host: DB_HOST,
      user: DB_USER,
      password: DB_PASS,
      database: DB_NAME,
      port: DB_PORT,
    });

    const [result] = await conn.execute(
      "INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)",
      [username, email, password_hash]
    );

    res.json({ ok: true, insertedId: result.insertId });
  } catch (err) {
    console.error("❌ Insert Error:", err.message);
    res.status(500).json({ ok: false, error: err.message });
  } finally {
    if (conn) await conn.end();
  }
});

// --------------------
// JOB (CRON) START
// --------------------
function safeStartCleanupJob() {
  try {
    const { startStoryCleanupJob } = require("./jobs/storyCleanup");
    startStoryCleanupJob();
    console.log("🧹 Cleanup job başlatıldı (node-cron)");
  } catch (err) {
    // node-cron kurulu değilse server yine çalışsın
    console.warn("⚠️ Cleanup job başlatılamadı:", err.message);
    console.warn("⚠️ Çözüm: npm install node-cron");
  }
}

// --------------------
// START SERVER
// --------------------
app.listen(PORT, () => {
  console.log(`✅ Listening: http://localhost:${PORT}`);
  console.log("ℹ️ DB:", { DB_HOST, DB_USER, DB_NAME, DB_PORT });

  // server ayakta kalktıktan sonra job'u başlat
  safeStartCleanupJob();
});
