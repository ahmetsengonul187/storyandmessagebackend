const db = require("../config/db");

// 1️⃣ Story paylaş
exports.createStory = async (req, res) => {
  const { user_id, image_url, video_url } = req.body;

  const expiresAt = new Date();
  expiresAt.setHours(expiresAt.getHours() + 24);

  await db.query(
    `INSERT INTO stories (user_id, image_url, video_url, expires_at)
     VALUES (?, ?, ?, ?)`,
    [user_id, image_url, video_url, expiresAt]
  );

  res.json({ message: "Story başarıyla paylaşıldı" });
};

// 2️⃣ Aktif story'leri getir
exports.getActiveStories = async (req, res) => {
  const [stories] = await db.query(
    `SELECT * FROM stories
     WHERE expires_at > NOW()
     ORDER BY created_at DESC`
  );

  res.json(stories);
};

// 3️⃣ Story görüntüle
exports.viewStory = async (req, res) => {
  const storyId = req.params.id;
  const { user_id } = req.body;

  try {
    await db.query(
      `INSERT INTO story_views (story_id, user_id)
       VALUES (?, ?)`,
      [storyId, user_id]
    );

    res.json({ message: "Story görüntülendi" });
  } catch (err) {
    res.status(400).json({ message: "Zaten görüntülenmiş" });
  }
};
